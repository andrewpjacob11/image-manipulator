package src.model;

import java.util.List;
import src.model.Pixel;

public interface IPhoto<K> {

  List<List<K>>filter(TransformationFilterMatrix filter);
  List<List<K>>colorTransformation(ColorFilterMatrix transform);

  List<List<Pixel>> getPixels();

  int getWidth();

  int getLength();

  @Override
  String toString();

  @Override
  boolean equals(Object other);
}
