package src.model;

import java.util.List;
import java.util.ArrayList;

/**
 * Represents a single pixel on an image. Contains three channels of colors: red, green, blue— each
 * with a value between 0 and 255.
 */
public class Pixel {

  private final double red;
  private final double green;
  private final double blue;

  /**
   * Creates a pixel of an image with pre-set red, green, blue values that can be altered later.
   *
   * @param red
   * @param green
   * @param blue
   */
  public Pixel(double red, double green, double blue) {
    this.red = clamp(red, 0, 255);
    this.green = clamp(green, 0, 255);
    this.blue = clamp(blue, 0, 255);


  }

  public Pixel(List<Double> newPixelData) {
    if (newPixelData.size() != 3) {
      throw new IllegalArgumentException("Invalid input list");
    }
    this.red = clamp(newPixelData.get(0), 0,255);
    this.green = clamp(newPixelData.get(1), 0,255);
    this.blue = clamp(newPixelData.get(2), 0,255);


  }

  /**
   * Retrieves the red channel value of a pixel.
   *
   * @return
   */
  public double getRed() {
    return this.red;
  }

  /**
   * Retrieves the green channel value of a pixel.
   *
   * @return
   */
  public double getGreen() {
    return this.green;
  }

  /**
   * Retrieves the blue channel value of a pixel.
   *
   * @return
   */
  public double getBlue() {
    return this.blue;
  }

  /**
   * Returns the pixel as a 1 dimensional List such in the format [Red, Green, Blue].
   *
   * @return pixel as List in the format specified above
   */
  public List<Double> pixelAsList() {
    return new ArrayList<Double>(List.of(this.red, this.green, this.blue));
  }

  @Override
  public String toString() {
    String returnString = (int) getRed() + "\n" + (int) getGreen() + "\n" + (int) getBlue() + "\n";
    return returnString;
  }

  protected double clamp(double input, double min, double max) {
    if (input < min) {
      return min;
    } else if(input>max){
      return max;
    }
    else{
      return input;
    }
  }

  @Override
  public boolean equals(Object other) {
    if (!(other instanceof Pixel)) {
      return false;
    }

    return (this.getRed() == ((Pixel) other).getRed() && this.getGreen() == ((Pixel) other)
        .getGreen() && this.getBlue() == ((Pixel) other).getBlue());
  }

}

