package src.model;

import java.util.List;

public interface IMatrixManipulator {

  public List<List<Pixel>> filterTransformation(TransformationFilterMatrix filterType);

  public List<List<Pixel>> colorHelper(ColorFilterMatrix color);
}
